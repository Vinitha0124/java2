package studentDetails.demo.repository;
import org.springframework.stereotype.Repository;
import studentDetails.demo.model.Student;
import org.springframework.data.mongodb.repository.MongoRepository;
@Repository
public interface Repo extends MongoRepository<Student, String> {

}
