package studentDetails.demo.model;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;

@Document(collection = "student_task")
@Data
@Getter
@Setter
@NoArgsConstructor
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String ID;
    private String Name;
    private LocalDate DOB;
    private String Branch;
    private float GPA;

    public Student(String ID, String name, LocalDate DOB, String branch, float GPA) {
        this.ID = ID;
        this.Name = name;
        this.DOB = DOB;
        this.Branch = branch;
        this.GPA = GPA;
    }

    public String getID() {
        return ID;
    }

    public String getName() {
        return Name;
    }

    public LocalDate getDOB() {
        return DOB;
    }

    public String getBranch() {
        return Branch;
    }

    public float getGPA() {
        return GPA;
    }
    public void setID(String ID) {
        this.ID = ID;
    }

    public void setBranch(String branch) {
        this.Branch = branch;
    }

    public void setGPA(float gpa) {
        this.GPA = gpa;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setDOB(LocalDate DOB) {
        this.DOB = DOB;
    }

}
